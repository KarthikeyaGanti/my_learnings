package com.airlines.admin.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.airlines.admin.vo.FlightVO;

@Entity
public class Admin {

	@Id
	private String adimUser;
	private String adminPassword;
	private Integer[] flight_Ids;
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(String adimUser, String adminPassword) {
		super();
		this.adimUser = adimUser;
		this.adminPassword = adminPassword;
	}
	public String getAdimUser() {
		return adimUser;
	}
	public void setAdimUser(String adimUser) {
		this.adimUser = adimUser;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public Integer[] getFlight_Ids() {
		return flight_Ids;
	}
	public void setFlight_Ids(Integer[] flight_Ids) {
		this.flight_Ids = flight_Ids;
	}
}
