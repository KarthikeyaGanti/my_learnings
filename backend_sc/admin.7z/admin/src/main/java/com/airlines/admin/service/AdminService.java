package com.airlines.admin.service;

import com.airlines.admin.Exception.AdminException;
import com.airlines.admin.entity.Admin;
import com.airlines.admin.vo.FlightVO;

public interface AdminService {

	public void adminLogin(Admin admin) throws AdminException;
	
	public void adminLogout();
	
	public String saveFlightIDs(String FID);
		
}
