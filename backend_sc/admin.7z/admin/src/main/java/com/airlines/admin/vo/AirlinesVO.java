package com.airlines.admin.vo;

public class AirlinesVO {

	private String airLineID;
	private String airLineName;
	private String airLineStatus;
	public String getAirLineStatus() {
		return airLineStatus;
	}
	public void setAirLineStatus(String airLineStatus) {
		this.airLineStatus = airLineStatus;
	}
	public AirlinesVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAirLineID() {
		return airLineID;
	}
	public void setAirLineID(String airLineID) {
		this.airLineID = airLineID;
	}
	public String getAirLineName() {
		return airLineName;
	}
	public void setAirLineName(String airLineName) {
		this.airLineName = airLineName;
	}
	public AirlinesVO(String airLineName) {
		super();
		this.airLineName = airLineName;
	}
}
