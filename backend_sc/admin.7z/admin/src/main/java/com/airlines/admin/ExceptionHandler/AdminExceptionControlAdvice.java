package com.airlines.admin.ExceptionHandler;

import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.airlines.admin.Exception.AdminException;
import com.airlines.admin.models.ExMessage;

@ControllerAdvice
public class AdminExceptionControlAdvice {


	@ExceptionHandler(AdminException.class)
	public ResponseEntity<?> adminExceptionHandler(Exception e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
		return new ResponseEntity<ExMessage>(new ExMessage(e.getMessage(), e.getClass()), org.springframework.http.HttpStatus.NOT_FOUND);
	}
}
