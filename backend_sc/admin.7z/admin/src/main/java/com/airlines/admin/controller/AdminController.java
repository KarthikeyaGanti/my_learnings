package com.airlines.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airlines.admin.client.AdminFlightClient;
import com.airlines.admin.service.AdminService;
import com.airlines.admin.vo.AirlinesVO;
import com.airlines.admin.vo.FlightVO;

import io.swagger.v3.core.util.Json;

@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private AdminFlightClient adminFlightClient;
	
//	@Autowired
//    private KafkaTemplate<String, AirlinesVO> kafkaTemplate;
//	
//	private static final String TOPIC = "addAirline-topic";

//	@GetMapping("/login")
//	public void adminLogin(@RequestBody Admin admin) throws AdminException{
//		adminService.adminLogin(admin);
//	}
	@PostMapping("/addairline")
	public String  addAirline(@RequestBody AirlinesVO airlinesVO){
		String output=  adminFlightClient.addAirLine(airlinesVO);
		return Json.pretty(output);
	}
	
	@PostMapping("/blockairline/{airLineID}")
	public String  blockAirline(@PathVariable String airLineID){
		String message=adminFlightClient.blockAirLine(airLineID);
		return Json.pretty(message);
	}
	@PostMapping("/unblockairline/{airLineID}")
	public String  unblockAirline(@PathVariable String airLineID){
		String message= adminFlightClient.unblockAirLine(airLineID);
		return Json.pretty(message);
	}
	@PostMapping("/addflight")
	public String addFlight(@RequestBody FlightVO flight) {
		String message= adminFlightClient.addFlight(flight);
		if(message.equalsIgnoreCase("no"))
			return Json.pretty("AIRLINE NOT FOUND");
		else {
			adminService.saveFlightIDs(message);
			return Json.pretty("FLIGHT ADDED WITH ID :"+message);
		}
		
	}
	@GetMapping("/allairlines")
	public List<AirlinesVO> getAllAirLines(){
		List<AirlinesVO> airlinesVOs=adminFlightClient.getAllAirLines();
		for(AirlinesVO a: airlinesVOs)
			System.err.println(a.getAirLineID());
		return airlinesVOs;
	}
	
	
//	@PostMapping("/kafka/addairline")
//	public String  kafkaBlockAirline(@RequestBody AirlinesVO vo){
//		String message="";
//        kafkaTemplate.send(TOPIC, vo);
//        return "Airline added successfully";
//	}

}
