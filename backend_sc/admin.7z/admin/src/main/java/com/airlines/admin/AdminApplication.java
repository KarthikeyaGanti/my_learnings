package com.airlines.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.airlines.admin.entity.Admin;
import com.airlines.admin.repo.AdminRepo;

@SpringBootApplication
@EnableFeignClients
public class AdminApplication implements CommandLineRunner{

	@Autowired
	AdminRepo adminRepo;
	public static void main(String[] args) {
		SpringApplication.run(AdminApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		saveAdmin();
	}
	
	public void saveAdmin() {
		Admin admin= new Admin("karthik", "karthik@123");
		adminRepo.save(admin);
	}

}
