package com.airlines.booking.serviceImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.LocalDataSourceJobStore;
import org.springframework.stereotype.Service;

import com.airlines.booking.VO.FlightVO;
import com.airlines.booking.VO.UserVO;
import com.airlines.booking.client.TicketFlightClient;
import com.airlines.booking.client.TicketUserClient;
import com.airlines.booking.entity.SeatsBooked;
import com.airlines.booking.entity.Ticket;
import com.airlines.booking.repo.BookingRepo;
import com.airlines.booking.repo.SeatsRepo;
import com.airlines.booking.service.BookingService;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepo bookingRepo;
	@Autowired
	private SeatsRepo seatsRepo;
	@Autowired
	private TicketFlightClient tfclient;
	@Autowired
	private TicketUserClient tuclient;
	
	static int ticket=0;
	static String k="";
	static int counter=0;
	@Override
	public String bookTicketByUser(String FID, UserVO user, Integer no_Of_Seats, String meal,List<String> seats) {
		FlightVO flight= tfclient.getFlightById(FID);
		Integer b_seats= flight.getBusiness_Seats();
		Integer nb_seats=flight.getNon_Business_seats();
		k=bookBusinessTicket(FID, seats);
		System.err.println(k);
		if(k=="nb"||k=="b")
			return generateticket(user, FID, meal, no_Of_Seats, seats);
		else
			return "TICKETS WITH REQESTED SEATS NOT AVAILABLE";
	}	
	
	
	public String generateticket(UserVO user,String FID,String meal,Integer no_Of_Seats,List<String> seats) {
		++ticket;
		String pnrNumber="PNR"+FID+"T"+ticket+k;
		Ticket ticket=new Ticket();
		ticket.setPnrNumber(pnrNumber);
		ticket.setFlightID(FID);
		ticket.setMeal(meal);
		ticket.setNo_Of_tickets(no_Of_Seats);
		ticket.setuEID(user.getuEId());
		List<String> s= ticket.getSeats();
		System.err.println(seats);
		System.err.println(s);
		for(String s1:seats) {
			s.add(s1);
		}
		ticket.setSeats(s);
		bookingRepo.save(ticket);
		return pnrNumber;
	}
	public String bookBusinessTicket(String FID,List<String> seats) {
		Optional<SeatsBooked> optional =seatsRepo.findById(FID);
		int count=0;
		if(optional.isEmpty()) {
			SeatsBooked sb= new SeatsBooked();
			sb.setFID(FID);
			sb.setBusiness_seats_booked(seats);
			return "b";
		}
		else {
			SeatsBooked sb= optional.get();
			if(sb.getBusiness_seats_booked().isEmpty()) {
				sb.setBusiness_seats_booked(seats);
				seatsRepo.save(sb);
				return "b";
			}
			else {
				List<String> b_seats=sb.getBusiness_seats_booked();
				for(String s:seats) {
					if(!b_seats.contains(s)) {
						count++;
					}
				}
				if(count==seats.size()) {
					for(String s:seats) {
						b_seats.add(s);
					}
					sb.setBusiness_seats_booked(b_seats);
					seatsRepo.save(sb);
					return "b";
				}
				else {
					return booknonBusinessTicket(FID,seats);
				}
			}
		}
	}
	
	public String booknonBusinessTicket(String FID, List<String> seats) {
		int count=0;
		Optional<SeatsBooked> optional =seatsRepo.findById(FID);
		SeatsBooked sb= optional.get();
		if(sb.getNon_business_seats_booked().isEmpty()) {
			sb.setNon_business_seats_booked(seats);
			return "nb";
		}
		else {
			List<String>nb_seats=sb.getNon_business_seats_booked();
			for(String s:seats) {
				if(!nb_seats.contains(s)) {
					count++;
				}
			}
			if(count==seats.size()) {
				for(String s:seats) {
					nb_seats.add(s);
				}
				sb.setNon_business_seats_booked(nb_seats);
				return "nb";
			}
			else 
				return "n";
		}
	}
	
	///////////////////////////////////////////
	
	public Ticket getTicketByPNR(String pnrNumber) {
		Optional<Ticket> optional= bookingRepo.findById(pnrNumber);
		return optional.get();
	}

	public List<Ticket> getTickets(String uEID){
		List<Ticket> tickets= new ArrayList<Ticket>();
		List<Ticket> ticketsFromDB=bookingRepo.findAll();
		for(Ticket t: ticketsFromDB) {
			if(t.getuEID().equals(uEID)){
				tickets.add(t);
			}
		}
		return tickets;
		
	}
	
	public String cancelTicket(String uEID,String pnrNumber) {
		String message="";
		Optional<Ticket> optional= bookingRepo.findById(pnrNumber);
		if(optional.isEmpty()) {
			message="NO";
		}
		else {
		Ticket ticket=optional.get();
		if(ticket.getuEID().equals(uEID)) {
			FlightVO flightVO= tfclient.getFlightById(ticket.getFlightID());
			LocalDate dateOfFlight=flightVO.getStart_date();
			int dayOfFlight=dateOfFlight.getDayOfMonth();
			int today=LocalDate.now().getDayOfMonth();
			if(dayOfFlight-today>=1) {
				bookingRepo.delete(ticket);
				message="success";
			}
			else
				message="failed";
			}
		}
		return message;
	}
		
}
	
	
