package com.airlines.booking.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.airlines.booking.VO.UserVO;

@FeignClient("UserService")
public interface TicketUserClient {

	@GetMapping("/user/byId")
	public UserVO getUserById(String EID);
}
