package com.airlines.booking.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Ticket {

	@Id
	@Column(name = "PNR")
	private String pnrNumber;
	private Integer no_Of_tickets;
	private String meal;
	private String flightID;
	private String uEID;
	@ElementCollection
	private List<String> seats = new ArrayList<String>();
	public String getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(String pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public Integer getNo_Of_tickets() {
		return no_Of_tickets;
	}
	public void setNo_Of_tickets(Integer no_Of_tickets) {
		this.no_Of_tickets = no_Of_tickets;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public String getFlightID() {
		return flightID;
	}
	public void setFlightID(String flightID) {
		this.flightID = flightID;
	}
	public String getuEID() {
		return uEID;
	}
	public void setuEID(String uEID) {
		this.uEID = uEID;
	}
	public List<String> getSeats() {
		return seats;
	}
	public void setSeats(List<String> seats) {
		this.seats = seats;
	}
	

	}
